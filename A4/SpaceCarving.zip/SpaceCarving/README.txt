SpaceCarving
------------

This demo is provided in the hope that it will be useful. For licensing reasons the data is not included in this package. Please download the dinosaur images and camera-matrices from:

http://www.robots.ox.ac.uk/~vgg/data/data-mview.html

These must be placed in the DinosaurData folder. 