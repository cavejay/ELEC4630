Dear Students, 
In this folder you will find several examples of ANA IFF HeP-2 imamges to try out your favourite segmentation method. Please only process the easy folder. The hard and extreme folders are for your information only and may help with your report.  

In the easy folder you will find:

borderline-FITC.tif
borderline_Mask.tif
hi_FITC.tif
hi_Mask.tif


The borderline cases have low fluorescence and are hard to segment.  The hi cases are much brighter and are relatively easy to segment.  The Mask files use a DAPI stain to delineate the cells and so they are effectively the gold standard for image segmentaion. 

Enjoy!

Brian