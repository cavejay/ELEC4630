clc, clear
%% Load ALL the images!
img1 = imread('20980008.jpg');
img2 = imread('20980035.jpg');
img3 = imread('20980060.jpg');
img4 = imread('20980065.jpg');
blue = imread('bluecar.jpg');
kings = imread('kingswood.jpg');

i = blue;
ig = i;

% get the size of the picture.
rs = size(ig, 1);
cs = size(ig, 2);

if size(i,3) == 3 % make sure it's gray
    ig = rgb2gray(i);
end

ig = histeq(ig);

% Normal edging
is = edge(ig, 'sobel');
ic = edge(ig, 'canny');

% Gauss then canny, also sobel
G = fspecial('gaussian',[5 5],2);
ib = imfilter(ig,G,'same');
ibc = edge(ib, 'canny');
ibs = edge(ib, 'sobel');

% Add them all together
itot = ibc + ic + is;

% Attempts a template match. Not used atm.
% n2 = imread('n2.jpg');
% n2 = im2double(n2);
% n2 = rgb2gray(n2);
% n2(n2 < 0.001) = -0.2;
% x = normxcorr2(n2, double(is));
% t = pad(ig, x);

% pre-proc for edge density
insl = bwareaopen(ibs, 10);
L = bwlabel(insl, 8);
STATS = regionprops(logical(L),'BoundingBox');
thresh = 100;

% remove long & thin bb's probs straight lines
% imshow(L)
% for p = 1:size(STATS),
%     bb = STATS(p).BoundingBox;
%     if bb(3) > thresh && bb(4) < bb(3)/10
%         L(L==p) = 0;
% %         rectangle('Position', bb, 'EdgeColor', 'green');
%     elseif bb(4) > thresh && bb(3) < bb(4)/10
%         L(L==p) = 0;
% %         rectangle('Position', bb, 'EdgeColor', 'blue');
%     else
% %         rectangle('Position', bb, 'EdgeColor', 'red');
%     end
% end

% we also use edge density check
H = fspecial('gaussian',[round(rs/5) round(cs/5)],5); 
tm = imfilter(double(logical(L)), H,'same'); % blur it a tonne
maxV = max(max(tm)); % get the highest value
allMaxValsMask = tm==maxV;
[R,C] = ind2sub(size(allMaxValsMask), find(allMaxValsMask));

SE = strel('disk',5,4);
dx = imdilate(allMaxValsMask, SE);

% Finding the entire number plate
% Get the value of the image at the plate.
val = double(ig(R,C));
bw = ig==val;
for i = -10:10,
    temp = ig==val+i;
    bw = bw + temp;
end

bw1 = im2bw(ig, (val+5)/255);
bw2 = im2bw(imcomplement(ig), (val-5)/255);


% Trial1
% sx = strel('pair', [0 1]);
% sy = strel('pair', [1 0]);
% ts = imclose(is, sx); % attempt to complete unfinished/broken lines
% ts = imclose(ts, sy);
% holes = imfill(ts, 'holes'); % find cut off areas
% s1 = strel('disk', 5, 0);
% t1 = imerode(holes, s1);
% F = bwlabel(t1);
% np = F(R,C);
% Mask = F==np;
% imshow(Mask);

% rawr = imfuse(dx, t1);
% figure(2), imshow(rawr)



















